# Aura Launcher
1. Install Android Studio (free). File > Open > select this folder, let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). The APK appears in app/build/outputs/apk/debug/.
3. Install it on your phone (allow "install unknown apps"), press Home, choose Aura Launcher > Always.
4. Tap the ✦ button to open Theme studio. Paste a Claude or OpenAI API key, describe a vibe, tap Generate.

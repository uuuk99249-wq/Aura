package com.aura.launcher

import android.graphics.Color
import org.json.JSONObject

data class LauncherTheme(
    val name: String = "Aurora",
    val bgTop: Int = 0xFF1B1B3A.toInt(),
    val bgBottom: Int = 0xFF693668.toInt(),
    val text: Int = Color.WHITE,
    val accent: Int = 0xFFA78BFA.toInt(),
    val shape: String = "squircle",
    val iconScale: Float = 1f,
    val columns: Int = 4,
    val showLabels: Boolean = true,
    val sound: String = "soft",
    val volume: Float = 0.6f
) {
    fun toJson() = JSONObject().apply {
        put("name", name); put("bgTop", hex(bgTop)); put("bgBottom", hex(bgBottom))
        put("text", hex(text)); put("accent", hex(accent)); put("shape", shape)
        put("iconScale", iconScale.toDouble()); put("columns", columns)
        put("showLabels", showLabels); put("sound", sound); put("volume", volume.toDouble())
    }

    companion object {
        private fun hex(c: Int) = String.format("#%06X", c and 0xFFFFFF)
        private fun col(j: JSONObject, k: String, d: Int) =
            try { Color.parseColor(j.getString(k)) } catch (e: Exception) { d }

        fun fromJson(j: JSONObject, b: LauncherTheme = LauncherTheme()) = LauncherTheme(
            name = j.optString("name", b.name),
            bgTop = col(j, "bgTop", b.bgTop),
            bgBottom = col(j, "bgBottom", b.bgBottom),
            text = col(j, "text", b.text),
            accent = col(j, "accent", b.accent),
            shape = j.optString("shape", b.shape).takeIf { it in listOf("circle", "squircle", "square") } ?: b.shape,
            iconScale = j.optDouble("iconScale", b.iconScale.toDouble()).toFloat().coerceIn(0.7f, 1.3f),
            columns = j.optInt("columns", b.columns).coerceIn(3, 6),
            showLabels = j.optBoolean("showLabels", b.showLabels),
            sound = j.optString("sound", b.sound).takeIf { it in listOf("soft", "glass", "wood") } ?: b.sound,
            volume = j.optDouble("volume", b.volume.toDouble()).toFloat().coerceIn(0f, 1f)
        )
    }
}

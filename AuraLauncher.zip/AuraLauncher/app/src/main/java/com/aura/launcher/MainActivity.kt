package com.aura.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    data class App(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

    private lateinit var prefs: SharedPreferences
    private lateinit var theme: LauncherTheme
    private val fx = SoundFx()
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var grid: GridView
    private lateinit var gear: TextView
    private var all = listOf<App>()
    private var shown = listOf<App>()
    private fun px(v: Int) = (v * resources.displayMetrics.density).toInt()

    private val appAdapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(p: Int) = shown[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, cv: View?, parent: ViewGroup?): View {
            val a = shown[p]
            val size = (resources.displayMetrics.widthPixels / theme.columns * 0.62f * theme.iconScale).toInt()
            val cell = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, px(10), 0, px(10))
            }
            cell.addView(ImageView(this@MainActivity).apply {
                setImageDrawable(a.icon)
                layoutParams = LinearLayout.LayoutParams(size, size)
                clipToOutline = true
                outlineProvider = object : ViewOutlineProvider() {
                    override fun getOutline(v: View, o: Outline) {
                        when (theme.shape) {
                            "circle" -> o.setOval(0, 0, v.width, v.height)
                            "square" -> o.setRoundRect(0, 0, v.width, v.height, v.width * 0.08f)
                            else -> o.setRoundRect(0, 0, v.width, v.height, v.width * 0.3f)
                        }
                    }
                }
            })
            if (theme.showLabels) cell.addView(TextView(this@MainActivity).apply {
                text = a.label; textSize = 11f; maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                gravity = Gravity.CENTER; setTextColor(theme.text); setPadding(px(2), px(6), px(2), 0)
            })
            return cell
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("aura", MODE_PRIVATE)
        theme = prefs.getString("theme", null)?.let { LauncherTheme.fromJson(JSONObject(it)) } ?: LauncherTheme()

        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.setOnApplyWindowInsetsListener { v, i ->
            v.setPadding(px(12), i.systemWindowInsetTop + px(8), px(12), i.systemWindowInsetBottom + px(8)); i
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        search = EditText(this).apply {
            hint = "Search apps"; setSingleLine(); setPadding(px(18), px(10), px(18), px(10))
            inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    val q = s.toString().trim()
                    shown = if (q.isEmpty()) all else all.filter { it.label.contains(q, true) }
                    appAdapter.notifyDataSetChanged()
                }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }
        gear = TextView(this).apply {
            text = "✦"; textSize = 26f; setPadding(px(16), 0, px(8), 0)
            setOnClickListener { openStudio() }
        }
        top.addView(search, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(gear)
        grid = GridView(this).apply {
            setSelector(android.R.color.transparent)
            adapter = appAdapter
            setOnItemClickListener { _, _, p, _ ->
                fx.play("tap", theme)
                startActivity(shown[p].intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            setOnItemLongClickListener { _, _, p, _ ->
                fx.play("open", theme)
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${shown[p].pkg}")))
                true
            }
        }
        root.addView(top)
        root.addView(grid, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
        applyTheme()
    }

    override fun onResume() { super.onResume(); loadApps() }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        search.setText(""); grid.smoothScrollToPosition(0)
    }

    @Deprecated("Launcher stays home")
    override fun onBackPressed() {}

    private fun loadApps() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        all = pm.queryIntentActivities(q, 0).mapNotNull { r ->
            val pkg = r.activityInfo.packageName
            if (pkg == packageName) null
            else App(r.loadLabel(pm).toString(), pkg, pm.getLaunchIntentForPackage(pkg) ?: return@mapNotNull null, r.loadIcon(pm))
        }.sortedBy { it.label.lowercase() }
        shown = all
        appAdapter.notifyDataSetChanged()
    }

    private fun applyTheme() {
        root.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(theme.bgTop, theme.bgBottom))
        search.background = GradientDrawable().apply {
            cornerRadius = px(24).toFloat(); setColor(Color.argb(40, 255, 255, 255)); setStroke(px(1), theme.accent)
        }
        search.setTextColor(theme.text)
        search.setHintTextColor((theme.text and 0xFFFFFF) or 0x88000000.toInt())
        gear.setTextColor(theme.accent)
        grid.numColumns = theme.columns
        appAdapter.notifyDataSetChanged()
    }

    private fun commit(t: LauncherTheme) {
        theme = t
        prefs.edit().putString("theme", t.toJson().toString()).apply()
        applyTheme()
    }

    private fun openStudio() {
        fx.play("open", theme)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(px(20), px(8), px(20), px(8)) }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, px(14), 0, px(2)); textSize = 13f }
        fun seek(max: Int, cur: Int, done: (Int) -> Unit) = SeekBar(this).apply {
            this.max = max; progress = cur
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { done(s!!.progress) }
            })
        }
        fun row(vararg opts: Pair<String, () -> Unit>) = LinearLayout(this).apply {
            opts.forEach { (n, f) ->
                addView(Button(this@MainActivity).apply { text = n; isAllCaps = false; setOnClickListener { fx.play("tap", theme); f() } },
                    LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }
        }

        // AI theme generator
        box.addView(label("✦ Generate a theme with AI"))
        val prompt = EditText(this).apply { hint = "e.g. rainy Tokyo night, neon pink on navy"; minLines = 2 }
        val prov = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Claude (Anthropic)", "OpenAI"))
            setSelection(prefs.getInt("prov", 0))
        }
        val key = EditText(this).apply {
            hint = "API key (stored only on this phone)"; setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        val status = TextView(this).apply { setPadding(0, px(6), 0, 0) }
        val gen = Button(this).apply { text = "Generate"; isAllCaps = false }
        gen.setOnClickListener {
            val k = key.text.toString().trim(); val p = prompt.text.toString().trim()
            if (k.isEmpty() || p.isEmpty()) { status.text = "Enter a prompt and an API key."; return@setOnClickListener }
            prefs.edit().putString("key", k).putInt("prov", prov.selectedItemPosition).apply()
            status.text = "Generating…"
            val base = theme
            Thread {
                try {
                    val t = AiThemeGenerator.generate(p, prov.selectedItemPosition, k, base)
                    runOnUiThread { commit(t); fx.play("ai", t); status.text = "Applied: ${t.name}" }
                } catch (e: Exception) { runOnUiThread { status.text = "Failed: ${e.message}" } }
            }.start()
        }
        listOf(prompt, prov, key, gen, status).forEach { box.addView(it) }

        // Manual controls
        box.addView(label("Columns"))
        box.addView(seek(3, theme.columns - 3) { commit(theme.copy(columns = it + 3)) })
        box.addView(label("Icon size"))
        box.addView(seek(60, ((theme.iconScale - 0.7f) * 100).toInt()) { commit(theme.copy(iconScale = 0.7f + it / 100f)) })
        box.addView(label("Icon shape"))
        box.addView(row("Circle" to { commit(theme.copy(shape = "circle")) },
            "Squircle" to { commit(theme.copy(shape = "squircle")) },
            "Square" to { commit(theme.copy(shape = "square")) }))
        box.addView(Switch(this).apply {
            text = "Show labels"; isChecked = theme.showLabels
            setOnCheckedChangeListener { _, c -> commit(theme.copy(showLabels = c)) }
        })
        box.addView(label("Sound pack"))
        box.addView(row("Soft" to { commit(theme.copy(sound = "soft")); fx.play("tap", theme) },
            "Glass" to { commit(theme.copy(sound = "glass")); fx.play("tap", theme) },
            "Wood" to { commit(theme.copy(sound = "wood")); fx.play("tap", theme) }))
        box.addView(label("Volume (0 = silent)"))
        box.addView(seek(100, (theme.volume * 100).toInt()) { commit(theme.copy(volume = it / 100f)); fx.play("tap", theme) })
        box.addView(label(""))
        box.addView(row("Reset theme" to { commit(LauncherTheme()) }))

        AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT)
            .setTitle("Theme studio").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Done", null).show()
    }
}

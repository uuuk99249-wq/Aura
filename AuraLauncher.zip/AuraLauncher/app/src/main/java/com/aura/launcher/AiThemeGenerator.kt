package com.aura.launcher

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** provider 0 = Anthropic (Claude), 1 = OpenAI-compatible. Bring your own API key. */
object AiThemeGenerator {
    private const val SYSTEM =
        "You design Android launcher themes. Reply with ONLY a JSON object, no prose, with keys: " +
        "name, bgTop, bgBottom, text, accent (hex like #RRGGBB), shape (circle|squircle|square), " +
        "iconScale (0.8-1.2), columns (3-6), showLabels (true|false), sound (soft|glass|wood). " +
        "Make text clearly readable on the background."

    fun generate(prompt: String, provider: Int, key: String, base: LauncherTheme): LauncherTheme {
        val raw = if (provider == 0) {
            val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 400)
                .put("system", SYSTEM)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            val res = post("https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body.toString())
            JSONObject(res).getJSONArray("content").getJSONObject(0).getString("text")
        } else {
            val body = JSONObject().put("model", "gpt-4o-mini").put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", SYSTEM))
                .put(JSONObject().put("role", "user").put("content", prompt)))
            val res = post("https://api.openai.com/v1/chat/completions",
                mapOf("Authorization" to "Bearer $key"), body.toString())
            JSONObject(res).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
        val json = raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)
        return LauncherTheme.fromJson(JSONObject(json), base)
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true
        c.connectTimeout = 15000; c.readTimeout = 45000
        c.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("HTTP ${c.responseCode}")
        return txt
    }
}

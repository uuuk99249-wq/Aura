package com.aura.launcher

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Synthesizes soft UI sounds in code, so no audio files are needed. */
class SoundFx {
    private val rate = 22050
    private val cache = HashMap<String, ShortArray>()

    fun play(kind: String, t: LauncherTheme) {
        if (t.volume <= 0f) return
        val data = cache.getOrPut("${t.sound}:$kind") { synth(t.sound, kind) }
        Thread {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(data.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC).build()
                track.write(data, 0, data.size)
                track.setVolume(t.volume)
                track.play()
                Thread.sleep(data.size * 1000L / rate + 120)
                track.release()
            } catch (_: Exception) {}
        }.start()
    }

    private fun synth(pack: String, kind: String): ShortArray {
        val (f0, dur) = when (kind) {
            "tap" -> 880.0 to 0.14
            "open" -> 660.0 to 0.28
            "ai" -> 1046.0 to 0.55
            else -> 520.0 to 0.16
        }
        val f = if (pack == "wood") f0 * 0.45 else f0
        val decay = when (pack) { "glass" -> 8.0; "wood" -> 38.0; else -> 16.0 }
        val n = (rate * dur).toInt()
        return ShortArray(n) { i ->
            val t = i / rate.toDouble()
            val freq = if (kind == "ai" && t > dur / 2) f * 1.5 else f
            var s = sin(2 * PI * freq * t)
            if (pack == "glass") s = s * 0.7 + 0.3 * sin(2 * PI * freq * 2.76 * t)
            val env = exp(-t * decay) * min(1.0, t / 0.004)
            (s * env * 0.6 * Short.MAX_VALUE).toInt().toShort()
        }
    }
}
